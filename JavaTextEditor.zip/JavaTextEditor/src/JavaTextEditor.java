import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.swing.JFileChooser;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class JavaTextEditor {
	static ArrayList<String> doc = new ArrayList<String>();
	
	public static int getCommand() {
		//this method prints the options to the user and stores the users choice
		Scanner scan = new Scanner(System.in);
		System.out.println("Main Menu\r\n" + 
				"Please make a selection:\r\n" + 
				"    1. Open a new document\r\n" + 
				"    2. Save the current document\r\n" + 
				"    3. Display the current document\r\n" + 
				"    4. Display a document line\r\n" + 
				"    5. Add a document line\r\n" + 
				"    6. Insert a document line\r\n" + 
				"    7. Change a document line\r\n" + 
				"    8. Delete a document line\r\n" + 
				"    9. End the program");
		int command = scan.nextInt();
		return command;
		}//end command()
	
	static void openDoc() throws IOException
	//this method lets the user select the text file they want to use
	{
	    JFileChooser chooser = new JFileChooser();
	    if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
	        File selectedFile = chooser.getSelectedFile();
	        Scanner fileReader = new Scanner( selectedFile );
	        
	        doc.clear();
	        while (fileReader.hasNextLine()) {
	            String line = fileReader.nextLine();
	            doc.add(line);
	        } // end inner while
	        
	        fileReader.close();
	    } // end outer if
	} // end openDoc
	
	public static void saveDoc() throws IOException{
	//this method saves the document
		JFileChooser chooser = new JFileChooser();
		 if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
		        File selectedFile = chooser.getSelectedFile();
		        FileWriter myWriter = new FileWriter(selectedFile);
				for(int i = 0; i < doc.size(); i++) {
					myWriter.append(doc.get(i));
					myWriter.append('\n');
				}
		        myWriter.close();
		       
		 }
	}
	
	public static void displayDoc() {
	//this method displays the text to the user
		for(int i = 0; i < doc.size(); i++) {
			System.out.println(doc.get(i));
		}
	}
	
	public static void displayLine() {
	//this method lets you choose a specific line of text to display
		Scanner scan = new Scanner(System.in);
		System.out.println("What line number would you like to display?");
		int lineNum = scan.nextInt();
		System.out.println(doc.get(lineNum));
	}
	
	public static void addTextatEnd() {
	//this method lets you add text to the end of the document
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter the new text you'd like to enter: ");
		String newText = scan.next();
		doc.add(newText);
	}
	
	public static void addTextatNewline() {
	//this method lets you add a new line of text before a chosen text line
		Scanner scan = new Scanner(System.in);
		System.out.println("What line number do you want to add the text before?");
		int prevLine = scan.nextInt();
		if (prevLine < 1 || prevLine > doc.size()) {
			System.out.println("***Invalid Line Number***");
			return;
		}
		System.out.println("What text would you like to add?");
		String newText2 = scan.next();
		doc.add(prevLine - 1, newText2);
	}
	
	public static void editLine() {
	//this method let you edit a certain text line
		Scanner scan = new Scanner(System.in);
		System.out.println("What line number do you want to edit");
		int editLine = scan.nextInt();
		if (editLine < 1 || editLine > doc.size()) {
			System.out.println("***Invalid Line Number***");
			return;
		}
		System.out.println("What text would you like to add?");
		String newText2 = scan.next();
		System.out.println("Change at line " + editLine + "; Are you sure?");
		String decision = scan.next();
		if (decision.equalsIgnoreCase("yes")) {
			doc.set(editLine, newText2);
		}
		else {
			return;
		}
	}
	
	public static void deleteLine() {
	//this method allows you to delete a line
		Scanner scan = new Scanner(System.in);
		System.out.println("What line number do you want to delete");
		int deleteLine = scan.nextInt();
		if (deleteLine < 1 || deleteLine > doc.size()) {
			System.out.println("***Invalid Line Number***");
			return;
		}
		System.out.println("Delete at line " + deleteLine + "; Are you sure?");
		String choice = scan.next();
		if (choice.equalsIgnoreCase("yes")) {
			doc.remove(deleteLine);
		}
		else {
			return;
		}
	}
	
	public static void main(String[] args) {
		//sets command and end command equal to defaults
		int command = 0;
        final int END_COMMAND = 9;
        //uses a while command so it ends when the user wants to end
        while (command != END_COMMAND)
        {
            try
            {
            	//calls the getCommand() method to get command set to each option in the menu
                command = getCommand();
                //uses the command given to open the requested method
                switch (command) {
                    case 1: // Open a Document
                    		openDoc();
                    		break;
                    case 2:
                    		saveDoc();
                    		break;
                    case 3:
                    		displayDoc();
                    		break;
                    case 4: 
                    		displayLine();
                    		break;
                    case 5: 
                    		addTextatEnd();
                    		break;
                    case 6: 
                    		addTextatNewline();
                    		break;
                    case 7:
                    		editLine();
                    		break;
                    case 8: 
                    		deleteLine();
                    		break;
                    case 9:// Exit the Program
                    	System.out.println("Thank you for using my program :)");
                    	System.exit(0);
                        break;
                    default: // Unknown Option
                        throw new Exception("Unknown option");
                } // end switch
            }
            catch (InputMismatchException ex) {
                System.out.print("Error: " + ex.getMessage());
            }
            catch (Exception ex) {
                System.out.println("Error: " + ex.getMessage());
            } // end try...catch
        } // end while
	}//end main

}
